import React from "react";
import { Container,InputGroup } from "react-bootstrap";
import Form from 'react-bootstrap/Form';
import {BsSearch} from 'react-icons/bs'


const Search=({handlesearch})=>{
    return(
        <>
        <Container>
        <InputGroup>
        <InputGroup.Text id="basic-addon1"><BsSearch /></InputGroup.Text>
        <Form.Control
          placeholder="Search Here" onChange={(e)=>handlesearch(e.target.value)}   />
      </InputGroup>
        </Container>
        
        </>
    )
}
export default Search