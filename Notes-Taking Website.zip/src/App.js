import { useEffect, useState } from "react";
import Noteslist from "./Components/Noteslist";
import {v4 as uuid} from "uuid";
import Search from "./Components/Search";
import Header from "./Components/Header";


function App() {
  const [notelist,setlist]=useState([]) 

  const [searchnote,setsearch]=useState('');

  const addnote=(text)=>{
    const date=new Date();
      const newnotee={
        id:uuid(),
        text:text,
        time:date.toLocaleDateString()
      }
      const newlist=[...notelist,newnotee]
      setlist(newlist)
  }
  
  const deleting=(id)=>{
    const newNotes = notelist.filter((note) => note.id != id);  //filter works fine than splice
		setlist(newNotes);
  }
  const searching=(notee)=>{

         setsearch(notee)
         console.log("in searching "+searchnote)
  }
  useEffect(()=>{
    const getfromlocal=JSON.parse(localStorage.getItem('app-notess'))
    if(getfromlocal.length>0){
      setlist(getfromlocal)
    }
   },[])

   useEffect(()=>{
    localStorage.setItem('app-notess',JSON.stringify(notelist))
   },[notelist])
    
   

  return (
    <div className="App">
      <Header />
      <Search handlesearch={searching}/>
         <Noteslist notes={notelist.filter((ele)=> ele.text.toLowerCase().includes(searchnote))} handleaddnotee={addnote} handledel={deleting} />         
          
        
    </div>
  );
}

export default App;
